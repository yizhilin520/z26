import React, { useState, useEffect, useRef } from "react";
import WrapHeader from "@/components/WrapHeader";
import Image from "@/components/Image";
import DefaultMatchImage from "@/assets/imgs/default_match_image.png";
import RenderJudge from "@/components/RenderJudge";
import LivePlayer from "@/components/LivePlayer2";
import Controller from "@/components/LivePlayer/components/Controller";
import BannerImg from "@/assets/imgs/banner.jpg";

import { getOnceMatchList, getTomorrowMatchInfo, getadConfig } from "@/api";
import Classnames from "classnames";
import Dayjs from "dayjs";
import { countdown } from "@/utils/common";

import "@/style/WrapDetailPage.scss";

const WrapDetailPage = (props) => {
  const playerRef = useRef();

  let matchId = props.match.params.id;
  let cusDate = props.match.params.type;

  const [matchUrlVoList, setMatchUrlVoList] = useState([]);
  const [matchWebVo, setMatchWebVo] = useState({});
  const [smatchScoreWebList, setSmatchScoreWebList] = useState([]);
  const [scoreList, setScoreList] = useState([]);
  const [detailBanner, setDetailBanner] = useState([]);

  const [idx, setIdx] = useState(0);
  const [videoData, setVideoData] = useState([]);
  const [time, setTime] = useState({
    bool: false,
    days: "0",
    hours: "00",
    minutes: "00",
    seconds: "00",
  });

  useEffect(() => {
    if (cusDate === "today") {
      fetchTodayData();
    } else {
      fetchTomorrowData();
    }
    getdetailAd();
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    let leftTime = Dayjs(matchWebVo.matchTime).valueOf() - Date.now();
    let timer = setInterval(() => {
      leftTime = leftTime - 1000;
      let {
        bool,
        days = "0",
        hours = "00",
        minutes = "00",
        seconds = "00",
      } = countdown(leftTime);
      if (bool) {
        // 结束倒计时
        clearInterval(timer);
      }
      setTime({
        bool,
        days,
        hours,
        minutes,
        seconds,
      });
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, [matchWebVo]);

  //获取banner
  const getdetailAd = async () => {
    let res = await getadConfig();
    if (res.code * 1 === 200 && res.data.length > 0) {
      setDetailBanner(res.data.filter((it) => it.type === 2));
    }
  };

  //获取今日单场比赛
  const fetchTodayData = () => {
    getOnceMatchList({ matchId: matchId }).then((res) => {
      if (res.code * 1 === 200 && res.data !== null) {
        setMatchUrlVoList(res.data.matchUrlVoList || []);
        setMatchWebVo(res.data.matchWebVo);
        setSmatchScoreWebList(res.data.smatchScoreWebList);
        let tempArr =
          res.data.smatchScoreWebList &&
          res.data.smatchScoreWebList.length > 0 &&
          res.data.smatchScoreWebList.filter((it) => it.type === "Current");
        setScoreList(tempArr);
        if (res.data.matchUrlVoList && res.data.matchUrlVoList.length > 0) {
          let dataV = res.data.matchUrlVoList[0];

          let isMac1 = isMac();
          let macDataUrl;
          if(isMac1 == true){
            macDataUrl = dataV.url.replace('flv','m3u8')
          }else{
            macDataUrl = dataV.url
          }
    
          setVideoData([
            {
              name: dataV.definition,
              protocolType: isMac1? "m3u8" :'flv',
              playUrl: macDataUrl,
              // playUrl: "http://play.lgx521.cn/live/189208.flv?txSecret=affd7293ecbb32c367100ef0f24f9cac&txTime=60716EBE",
            },
          ]);
        }
      }
    });
  };
  // 判断苹果浏览器
  const isMac = () =>{
    var agent = navigator.userAgent || navigator.vendor || window.opera;
    if (agent != null) {
      if (/macintosh|mac os x/i.test(agent.toLowerCase())) return true;
      return false;
    }
  }

  // 获取明日单场比赛
  const fetchTomorrowData = () => {
    getTomorrowMatchInfo({ matchId: matchId }).then((res) => {
      if (res.code * 1 === 200 && res.data !== null) {
        setMatchWebVo(res.data.matchWebVo);
      }
    });
  };

  useEffect(() => {
    // if (matchUrlVoList && matchUrlVoList.length > 0) {

    if (videoData && videoData.length) {
      playerRef.current.create();
    } else {
      playerRef.current.destroy();
    }
    // }
  }, [videoData]);

  const handlePlayUrl = (item, index) => {
    setIdx(index);
    //     name: "原画"
    // playUrl: "http://play.lgx521.cn/live/189041.flv?txSecret=78b736025cf6c4a643806b7810d15477&txTime=60716850"
    // protocolType: "flv"

    let isMac1 = isMac();
    let macDataUrl;
    if(isMac1 == true){
      macDataUrl = item.url.replace('flv','m3u8')
    }else{
      macDataUrl = item.url
    }

    let data = {
      name: item.definition,
      protocolType: isMac1? "m3u8" :'flv',
      playUrl: macDataUrl,
    };
    setVideoData([data]);
  };

  return (
    <div className="wrap_detail">
      <div className="heder_top">
        <WrapHeader />
      </div>
      <div className="detail_box">
        <div className="vs_wrap">
          <div className="vs">
            <RenderJudge
              value={matchWebVo.homeTeamLogo}
              active={
                <Image className="team_logo" src={matchWebVo.homeTeamLogo} />
              }
              inactive={<Image src={DefaultMatchImage} className="team_logo" />}
            />
            <div className="match_name">{matchWebVo.homeTeamName}</div>
          </div>
          <div className="vs">
            <div className="sport_name">{matchWebVo.tournamentName}</div>
            <div className="time">
              {matchWebVo.matchTime ? (
                <>
                  <span>{Dayjs(matchWebVo.matchTime).format("MM-DD")}</span> |
                  {Dayjs(matchWebVo.matchTime).format("HH:mm")}
                </>
              ) : (
                ""
              )}
            </div>
          </div>
          <div className="vs">
            <RenderJudge
              value={matchWebVo.awayTeamLogo}
              active={
                <Image className="team_logo" src={matchWebVo.awayTeamLogo} />
              }
              inactive={<Image src={DefaultMatchImage} className="team_logo" />}
            />
            <div className="match_name"> {matchWebVo.awayTeamName}</div>
          </div>
        </div>

        <div className="play_wrap">
          <LivePlayer
            ref={playerRef}
            data={videoData}
            ctrl={<Controller />}
          ></LivePlayer>
          <RenderJudge
            value={cusDate === "today" && videoData.length === 0}
            active={
              <div className="countDown">
                <div className="down_text ">
                  <div className="no_video">
                    <p className="no_video_text">本场比赛暂无视频</p>
                  </div>
                </div>
              </div>
            }
          />
          <RenderJudge
            value={cusDate === "tomorrow"}
            active={
              <div className="countDown">
                <div className="down_text">
                  {`距赛事直播还有${time.days}天${time.hours}时${time.minutes}分${time.seconds}秒`}
                </div>
              </div>
            }
          />
        </div>
        <div className="btns">
          <RenderJudge
            value={matchUrlVoList && matchUrlVoList.length > 0}
            active={
              <>
                {matchUrlVoList.length > 0 &&
                  matchUrlVoList.map((it, index) => (
                    <div
                      className={Classnames(
                        "btn",
                        index === idx ? "active" : ""
                      )}
                      key={index}
                      onClick={() => handlePlayUrl(it, index)}
                    >
                      {it.definition}
                    </div>
                  ))}
              </>
            }
            inactive={<div className="btn ">暂无信号</div>}
          />
        </div>
        <div className="advert" style={{marginTop: matchUrlVoList && matchUrlVoList.length > 3 ? '10%' : '3%'}}>
          <RenderJudge
            value={detailBanner.length}
            active={
              <Image src={detailBanner.length > 0 && detailBanner[0].content} />
            }
          />
        </div>
      </div>
    </div>
  );
};

export default WrapDetailPage;
