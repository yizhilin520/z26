import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Image from "@/components/Image";
import DefaultMatchImage from "@/assets/imgs/default_match_image.png";
import RenderJudge from "@/components/RenderJudge";
import NotData from "@/components/NotData";
import Carousel from "@/components/Carousel";
import Dayjs from "dayjs";
import { getTodayMatchList, getTomorrowMatchList, getadConfig } from "@/api";
import Iconfont from "@/components/Iconfont";

import "@/style/MatchPage.scss";

const PcList = () => {
  const oWidth =
    document.body.clientWidth || document.documentElement.clientWidth;

  const [matchList, setMatchList] = useState([]);
  const [tomorrowList, setTomorrowList] = useState([]);
  const [dataList, setDataList] = useState([]);
  const [tomorrowData, setTomorrowData] = useState([]);
  const [showTodayMore, setShowTodayMore] = useState(false);
  const [showTomorrowMore, setShowTomorrowMore] = useState(false);
  const [pageSize, setPageSize] = useState(20);
  const [pageNum, setPageNum] = useState(1);
  const [pageSizeT, setPageSizeT] = useState(20);
  const [pageNumT, setPageNumT] = useState(1);

  const [todayLoading, setTodayLoading] = useState(false);
  const [tomorrowLoading, setTomorrowLoading] = useState(false);

  const [homeBanner, setHomeBanner] = useState([]);
  const pcRef = useRef();

  useEffect(() => {
    if (oWidth > 750) {
      fetchTodayList();
      fetchTomorrowList();
      getAdInfoData();
      setPageNum(1);
      setPageNumT(1);
    }
  }, []);

  const getAdInfoData = async () => {
    let res = await getadConfig();
    if (res.code * 1 === 200) {
      setHomeBanner(res.data.filter((it) => it.type === 1));
    }
  };

  const fetchTodayList = async () => {
    setTodayLoading(true);
    let res = await getTodayMatchList();
    if (res.code * 1 === 200) {
      setDataList(res.data);
      setMatchList(res.data.slice(0, pageSize * pageNum));
      setPageNum(pageNum + 1);
      setTodayLoading(false);
    }
  };

  const fetchTomorrowList = async () => {
    setTomorrowLoading(true);
    let result = await getTomorrowMatchList();
    if (result.code * 1 === 200) {
      setTomorrowData(result.data);
      setTomorrowList(result.data.slice(0, pageSizeT * pageNumT));
      setPageNumT(pageNumT + 1);
      setTomorrowLoading(false);
    }
  };

  //今日加载更多
  const handleMore = () => {
    if (matchList.length === dataList.length) {
      setShowTodayMore(true);
      return;
    }
    setPageNum(pageNum + 1);
    let sliceData = dataList.slice(0, pageSize * pageNum);
    console.log(sliceData, "today");
    setMatchList(sliceData);
  };
  // 明日加载更多
  const handleMoreT = () => {
    if (tomorrowList.length === tomorrowData.length) {
      setShowTomorrowMore(true);
      return;
    }
    setPageNumT(pageNumT + 1);
    let sliceDataT = tomorrowData.slice(0, pageSizeT * pageNumT);
    console.log(sliceDataT, "tomorrow");
    setTomorrowList(sliceDataT);
  };

  const handleToTop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    pcRef.current.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <div className="pc" ref={pcRef}>
      <Header />
      <div className="contentList">
        {/* <RenderJudge
          value={true}
          active={<Image className="banner" src={BannerImg} />}
        /> */}
        {/* 轮播 */}
        <Carousel list={homeBanner} height="200px" />

        {/* 今日直播 start */}
        <div className="taday">
          <div className="title">今日直播</div>
          <RenderJudge
            value={matchList.length > 0}
            active={
              <>
                {matchList.map((it) => {
                  return (
                    <div className="list_item" key={it.matchId}>
                      <div className="text">
                        <RenderJudge
                          value={it.tournamentLogoUrl}
                          active={
                            <Image
                              src={it.tournamentLogoUrl}
                              className="team_logo"
                            />
                          }
                          inactive={
                            <Image
                              src={DefaultMatchImage}
                              className="team_logo"
                            />
                          }
                        />
                        <div className="text_name">{it.tournamentName}</div>
                      </div>

                      <div className="date">
                        {Dayjs(it.matchTime).format("MM-DD HH:mm")}
                      </div>
                      <div className="middle">
                        <div className="left">
                          <div className="left_text">{it.homeTeamName}</div>
                          <RenderJudge
                            value={it.homeTeamLogo}
                            active={
                              <Image
                                src={it.homeTeamLogo}
                                className="team_logo"
                              />
                            }
                            inactive={
                              <Image
                                src={DefaultMatchImage}
                                className="team_logo"
                              />
                            }
                          />
                        </div>
                        <div className="vs_box">
                          <div className="vs"></div>
                        </div>
                        <div className="right">
                          <RenderJudge
                            value={it.awayTeamLogo}
                            active={
                              <Image
                                src={it.awayTeamLogo}
                                className="team_logo"
                              />
                            }
                            inactive={
                              <Image
                                src={DefaultMatchImage}
                                className="team_logo"
                              />
                            }
                          />
                          <div className="right_text">{it.awayTeamName}</div>
                        </div>
                      </div>
                      <div className="live_txt">
                        <Link
                          target="_blank"
                          to={`/detail/today/${it.matchId}`}
                        >
                          <span className="jump_text">视频直播</span>
                        </Link>
                      </div>
                    </div>
                  );
                })}
                <div className="more list_item" onClick={handleMore}>
                  {showTodayMore ? "暂无更多" : "点击加载更多"}
                </div>
              </>
            }
            inactive={
              <RenderJudge
                value={todayLoading}
                active={
                  <div
                    style={{
                      textAlign: "center",
                      fontSize: "16px",
                    }}
                  >
                    加载中...
                  </div>
                }
                inactive={<NotData />}
              />
            }
          />
        </div>
        {/* 今日直播 end */}

        {/* 明日直播 start */}
        <div className="taday">
          <div className="title">明日直播</div>
          <RenderJudge
            value={tomorrowList.length > 0}
            active={
              <>
                {tomorrowList.map((it) => {
                  return (
                    <div className="list_item" key={it.matchId}>
                      <div className="text">
                        <RenderJudge
                          value={it.tournamentLogoUrl}
                          active={
                            <Image
                              src={it.tournamentLogoUrl}
                              className="team_logo"
                            />
                          }
                          inactive={
                            <Image
                              src={DefaultMatchImage}
                              className="team_logo"
                            />
                          }
                        />
                        <div className="text_name">{it.tournamentName}</div>
                      </div>
                      <div className="date">
                        {Dayjs(it.matchTime).format("MM-DD HH:mm")}
                      </div>
                      <div className="middle">
                        <div className="left">
                          <div className="left_text">{it.homeTeamName}</div>
                          <RenderJudge
                            value={it.homeTeamLogo}
                            active={
                              <Image
                                src={it.homeTeamLogo}
                                className="team_logo"
                              />
                            }
                            inactive={
                              <Image
                                src={DefaultMatchImage}
                                className="team_logo"
                              />
                            }
                          />
                        </div>
                        <div className="vs_box">
                          <div className="vs"></div>
                        </div>
                        <div className="right">
                          <RenderJudge
                            value={it.awayTeamLogo}
                            active={
                              <Image
                                src={it.awayTeamLogo}
                                className="team_logo"
                              />
                            }
                            inactive={
                              <Image
                                src={DefaultMatchImage}
                                className="team_logo"
                              />
                            }
                          />
                          <div className="right_text">{it.awayTeamName}</div>
                        </div>
                      </div>
                      <div className="live_txt">
                        <Link
                          target="_blank"
                          to={`/detail/tomorrow/${it.matchId}`}
                        >
                          <span className="jump_text">视频直播</span>
                        </Link>
                      </div>
                    </div>
                  );
                })}
                <div className="more list_item" onClick={handleMoreT}>
                  {showTomorrowMore ? "暂无更多" : "点击加载更多"}
                </div>
              </>
            }
            inactive={
              <RenderJudge
                value={tomorrowLoading}
                active={
                  <div
                    style={{
                      textAlign: "center",
                      fontSize: "16px",
                    }}
                  >
                    加载中...
                  </div>
                }
                inactive={<NotData />}
              />
            }
          />
        </div>
        {/* 明日直播 end */}
        <RenderJudge
          value={tomorrowList.length}
          active={
            <div onClick={(e) => handleToTop(e)} className="line2">
              <Iconfont name="fanhuidingbu" className={"icon"} /> &nbsp;顶部
            </div>
          }
        />
      </div>
    </div>
  );
};

export default PcList;
