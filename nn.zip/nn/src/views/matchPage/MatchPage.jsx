import React, { useState, useEffect } from "react";
import RenderJudge from "@/components/RenderJudge";
import PcList from "@/views/pcList/PcList";
import WrapList from "@/views/wrapList/WrapList";

const MatchPage = () => {
  const oWidth =
    document.body.clientWidth || document.documentElement.clientWidth;

  const [isPc, setIsPc] = useState(true);

  useEffect(() => {
    oWidth > 750 ? setIsPc(true) : setIsPc(false);
  }, [oWidth]);

  return (
    <>
      <RenderJudge value={isPc} active={<PcList />} inactive={<WrapList />} />
    </>
  );
};

export default MatchPage;
