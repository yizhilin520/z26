import React, { useState, useEffect, useRef } from "react";
import Header from "@/components/Header";
import Image from "@/components/Image";
import LivePlayer from "@/components/LivePlayer";
import Controller from "@/components/LivePlayer/components/Controller";
import RenderJudge from "@/components/RenderJudge";
import BannerImg from "@/assets/imgs/banner.jpg";
import DefaultMatchImage from "@/assets/imgs/default_match_image.png";
import { getOnceMatchList, getTomorrowMatchInfo, getadConfig } from "@/api";
import Classnames from "classnames";
import Dayjs from "dayjs";
import { countdown } from "@/utils/common";
import "@/style/DetailPage.scss";

const DetailPage = (props) => {
  const playerRef = useRef();
  let matchId = props.match.params.id;
  let cusDate = props.match.params.type;

  const [matchUrlVoList, setMatchUrlVoList] = useState([]);
  const [matchWebVo, setMatchWebVo] = useState({});
  const [smatchScoreWebList, setSmatchScoreWebList] = useState([]);
  const [scoreList, setScoreList] = useState([]);

  const [detailBanner, setDetailBanner] = useState([]);

  const [idx, setIdx] = useState(0);
  const [videoData, setVideoData] = useState([]);
  const [time, setTime] = useState({
    bool: false,
    days: "0",
    hours: "00",
    minutes: "00",
    seconds: "00",
  });

  useEffect(() => {
    if (cusDate === "today") {
      fetchTodayData();
    } else {
      fetchTomorrowData();
    }
    getdetailAd();
  }, []);

  useEffect(() => {
    let leftTime = Dayjs(matchWebVo.matchTime).valueOf() - Date.now();
    let timer = setInterval(() => {
      leftTime = leftTime - 1000;
      let {
        bool,
        days = "0",
        hours = "00",
        minutes = "00",
        seconds = "00",
      } = countdown(leftTime);
      if (bool) {
        // 结束倒计时
        clearInterval(timer);
      }
      setTime({
        bool,
        days,
        hours,
        minutes,
        seconds,
      });
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, [matchWebVo]);

  //获取banner
  const getdetailAd = async () => {
    let res = await getadConfig();
    if (res.code * 1 === 200) {
      setDetailBanner(res.data.filter((it) => it.type === 2));
    }
  };
  //获取今日单场比赛
  const fetchTodayData = () => {
    getOnceMatchList({ matchId: matchId }).then((res) => {
      if (res.code * 1 === 200 && res.data !== null) {
        setMatchUrlVoList(res.data.matchUrlVoList || []);
        setMatchWebVo(res.data.matchWebVo);
        setSmatchScoreWebList(res.data.smatchScoreWebList);
        let tempArr = res.data.smatchScoreWebList.filter(
          (it) => it.type === "Current"
        );
        setScoreList(tempArr);
        if (res.data.matchUrlVoList && res.data.matchUrlVoList.length > 0) {
          let dataV = res.data.matchUrlVoList[0];
          setVideoData([
            {
              name: dataV.definition,
              protocolType: "flv",
              playUrl: dataV.url,
              // playUrl: "http://play.lgx521.cn/live/189208.flv?txSecret=affd7293ecbb32c367100ef0f24f9cac&txTime=60716EBE",
            },
          ]);
        }
      }
    });
  };

  // 获取明日单场比赛
  const fetchTomorrowData = () => {
    getTomorrowMatchInfo({ matchId: matchId }).then((res) => {
      if (res.code * 1 === 200 && res.data !== null) {
        setMatchWebVo(res.data.matchWebVo);
      }
    });
  };

  useEffect(() => {
    // if (matchUrlVoList && matchUrlVoList.length > 0) {

    if (videoData && videoData.length) {
      playerRef.current.create();
    } else {
      playerRef.current.destroy();
    }
    // }
  }, [videoData]);

  const handlePlayUrl = (item, index) => {
    setIdx(index);
    //     name: "原画"
    // playUrl: "http://play.lgx521.cn/live/189041.flv?txSecret=78b736025cf6c4a643806b7810d15477&txTime=60716850"
    // protocolType: "flv"
    let data = {
      name: item.definition,
      protocolType: "flv",
      playUrl: item.url,
    };
    setVideoData([data]);
  };

  return (
    <>
      <Header show={false} />
      <div className="detail_page">
        <div className="banner">
          <div className="list1">
            <span className="name1 homeTeam">{matchWebVo.homeTeamName}</span>
            <RenderJudge
              value={matchWebVo.homeTeamLogo}
              active={
                <Image src={matchWebVo.homeTeamLogo} className="team_logo" />
              }
              inactive={<Image src={DefaultMatchImage} className="team_logo" />}
            />
          </div>
          <div className="list2">
            <div className="gameName matchTitle">
              {matchWebVo.tournamentName}
            </div>
            <>
              <RenderJudge
                value={matchWebVo.status === 2}
                active={
                  <div className="team_box">
                    <p className="score">
                      {scoreList.length > 0 && scoreList[0].team1}
                    </p>
                    <p className="gameTime ">{matchWebVo.statusName}</p>
                    <p className="score">
                      {scoreList.length > 0 && scoreList[0].team2}
                    </p>
                  </div>
                }
                inactive={
                  <div className="team_box">
                    <p>
                      {matchWebVo.matchTime
                        ? Dayjs(matchWebVo.matchTime).format("MM-DD HH:mm")
                        : ""}
                    </p>
                  </div>
                }
              />
            </>
          </div>
          <div className="list3">
            <span className="name2 visitingTeam">
              {matchWebVo.awayTeamName}
            </span>
            <RenderJudge
              value={matchWebVo.awayTeamLogo}
              active={
                <Image src={matchWebVo.awayTeamLogo} className="team_logo" />
              }
              inactive={<Image src={DefaultMatchImage} className="team_logo" />}
            />
          </div>
        </div>
        <div className="play_wrap">
          <LivePlayer
            ref={playerRef}
            data={videoData}
            ctrl={<Controller />}
          ></LivePlayer>
          <RenderJudge
            value={cusDate === "today" && videoData.length === 0}
            active={
              <div className="countDown">
                <div className="down_text ">
                  <div className="no_video">
                    <p className="no_video_text">本场比赛暂无视频</p>
                  </div>
                </div>
              </div>
            }
          />
          <RenderJudge
            value={cusDate === "tomorrow"}
            active={
              <div className="countDown">
                <div className="down_text">
                  {`距赛事直播还有${time.days}天${time.hours}时${time.minutes}分${time.seconds}秒`}
                </div>
              </div>
            }
          />
        </div>
        <div className="btns">
          <RenderJudge
            value={matchUrlVoList && matchUrlVoList.length > 0}
            active={
              <>
                {matchUrlVoList.length > 0 &&
                  matchUrlVoList.map((it, index) => (
                    <div
                      className={Classnames(
                        "btn",
                        index === idx ? "active" : ""
                      )}
                      key={index}
                      onClick={() => handlePlayUrl(it, index)}
                    >
                      {it.definition}
                    </div>
                  ))}
              </>
            }
            inactive={<div className="btn">暂无信号</div>}
          />

          {/* <div className="btn active">信号源1</div>
          <div className="btn">信号源2</div> */}
        </div>
        <div className="advert">
          <RenderJudge
            value={detailBanner.length}
            active={
              <Image src={detailBanner.length > 0 && detailBanner[0].content} />
            }
          />
        </div>
      </div>
    </>
  );
};

export default DetailPage;
