import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import WrapHeader from "@/components/WrapHeader";
import Iconfont from "@/components/Iconfont";
import Image from "@/components/Image";
import DefaultMatchImage from "@/assets/imgs/default_match_image.png";
import RenderJudge from "@/components/RenderJudge";
import NotData from "@/components/NotData";
import Dayjs from "dayjs";
import Carousel from "@/components/Carousel";
import { getTodayMatchList, getTomorrowMatchList, getadConfig } from "@/api";

import "@/style/MatchPage.scss";

const bg = true;
const WrapList = () => {
  const oWidth =
    document.body.clientWidth || document.documentElement.clientWidth;

  const [tLoading, setTLoading] = useState(false);
  const [mLoading, setMLoading] = useState(false);

  const [matchList, setMatchList] = useState([]);
  const [tomorrowList, setTomorrowList] = useState([]);
  const [dataList, setDataList] = useState([]);
  const [tomorrowData, setTomorrowData] = useState([]);
  const [showTodayMore, setShowTodayMore] = useState(false);
  const [showTomorrowMore, setShowTomorrowMore] = useState(false);
  const [pageSize, setPageSize] = useState(20);
  const [pageNum, setPageNum] = useState(1);
  const [pageSizeT, setPageSizeT] = useState(20);
  const [pageNumT, setPageNumT] = useState(1);

  const [homeBanner, setHomeBanner] = useState([]);

  useEffect(() => {
    if (oWidth < 750) {
      fetchTodayList();
      fetchTomorrowList();
      getAdInfoData();
      setPageNum(1);
      setPageNumT(1);
    }
  }, []);

  const getAdInfoData = async () => {
    let res = await getadConfig();
    if (res.code * 1 === 200) {
      setHomeBanner(res.data.filter((it) => it.type === 1));
    }
  };

  const fetchTodayList = async () => {
    setTLoading(true);
    let res = await getTodayMatchList();
    if (res.code * 1 === 200) {
      setDataList(res.data);
      setMatchList(res.data.slice(0, pageSize * pageNum));
      setPageNum(pageNum + 1);
      setTLoading(false);
    }
  };

  const fetchTomorrowList = async () => {
    setMLoading(true);
    let result = await getTomorrowMatchList();
    if (result.code * 1 === 200) {
      setTomorrowData(result.data);
      setTomorrowList(result.data.slice(0, pageSizeT * pageNumT));
      setPageNumT(pageNumT + 1);
      setMLoading(false);
    }
  };

  //今日加载更多
  const handleMore = () => {
    if (matchList.length === dataList.length) {
      setShowTodayMore(true);
      return;
    }
    setPageNum(pageNum + 1);
    let sliceData = dataList.slice(0, pageSize * pageNum);
    console.log(sliceData, "today");
    setMatchList(sliceData);
  };
  // 明日加载更多
  const handleMoreT = () => {
    if (tomorrowList.length === tomorrowData.length) {
      setShowTomorrowMore(true);
      return;
    }
    setPageNumT(pageNumT + 1);
    let sliceDataT = tomorrowData.slice(0, pageSizeT * pageNumT);
    console.log(sliceDataT, "tomorrow");
    setTomorrowList(sliceDataT);
  };

  const handleToTop = (e) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <div className="h5">
      <div className="home_top" style={{ height: bg ? "205px" : "80px" }}>
        <WrapHeader />
        {/* <RenderJudge
          value={bg}
          active={<Image className="home_banner" src={BannerImg} />}
        /> */}
        <div className="cus_carousel">
          <Carousel list={homeBanner} height="120px" />
        </div>
      </div>

      <div className="wrap_list">
        <div className="wrap_list_item" style={{ marginBottom: "20vh" }}>
          <div className="title">今日比赛</div>
          <RenderJudge
            value={matchList.length > 0}
            active={
              <div className="cell_box">
                {matchList.map((it) => {
                  return (
                    <Link
                      to={`/wrap_detail/today/${it.matchId}`}
                      key={it.matchId}
                    >
                      <div className="cell">
                        <div className="cell_left">
                          <RenderJudge
                            value={it.homeTeamLogo}
                            active={
                              <Image
                                className="team_logo"
                                src={it.homeTeamLogo}
                              />
                            }
                            inactive={
                              <Image
                                src={DefaultMatchImage}
                                className="team_logo"
                              />
                            }
                          />
                          <div className="match_name">{it.homeTeamName}</div>
                        </div>
                        <div className="cell_center">
                          <div className="sport_name">{it.tournamentName}</div>
                          <div className="time">
                            <span>{Dayjs(it.matchTime).format("MM-DD")}</span> |{" "}
                            {Dayjs(it.matchTime).format("HH:mm")}
                          </div>
                        </div>
                        <div className="cell_right">
                          <RenderJudge
                            value={it.awayTeamLogo}
                            active={
                              <Image
                                className="team_logo"
                                src={it.awayTeamLogo}
                              />
                            }
                            inactive={
                              <Image
                                src={DefaultMatchImage}
                                className="team_logo"
                              />
                            }
                          />
                          <div className="match_name">{it.awayTeamName}</div>
                        </div>
                      </div>
                    </Link>
                  );
                })}
                <div className="more list_item" onClick={handleMore}>
                  {showTodayMore ? "暂无更多" : "点击加载更多"}
                </div>
              </div>
            }
            inactive={
              <RenderJudge
                value={tLoading}
                active={
                  <div
                    style={{
                      textAlign: "center",
                      fontSize: "16px",
                    }}
                  >
                    加载中...
                  </div>
                }
                inactive={<NotData />}
              />
            }
          />
        </div>

        <div className="line"></div>

        <div className="wrap_list_item">
          <div className="title">明日比赛</div>
          <RenderJudge
            value={tomorrowList.length > 0}
            active={
              <div className="cell_box">
                {tomorrowList.map((it) => {
                  return (
                    <Link
                      to={`/wrap_detail/tomorrow/${it.matchId}`}
                      key={it.matchId}
                    >
                      <div className="cell">
                        <div className="cell_left">
                          <RenderJudge
                            value={it.homeTeamLogo}
                            active={
                              <Image
                                className="team_logo"
                                src={it.homeTeamLogo}
                              />
                            }
                            inactive={
                              <Image
                                src={DefaultMatchImage}
                                className="team_logo"
                              />
                            }
                          />
                          <div className="match_name">{it.homeTeamName}</div>
                        </div>
                        <div className="cell_center">
                          <div className="sport_name">{it.tournamentName}</div>
                          <div className="time">
                            <span>{Dayjs(it.matchTime).format("MM-DD")}</span> | {Dayjs(it.matchTime).format("HH:mm")}
                          </div>
                        </div>
                        <div className="cell_right">
                          <RenderJudge
                            value={it.awayTeamLogo}
                            active={
                              <Image
                                className="team_logo"
                                src={it.awayTeamLogo}
                              />
                            }
                            inactive={
                              <Image
                                src={DefaultMatchImage}
                                className="team_logo"
                              />
                            }
                          />
                          <div className="match_name">{it.awayTeamName}</div>
                        </div>
                      </div>
                    </Link>
                  );
                })}
                <div className="more list_item" onClick={handleMoreT}>
                  {showTomorrowMore ? "暂无更多" : "点击加载更多"}
                </div>
              </div>
            }
            inactive={
              <RenderJudge
                value={mLoading}
                active={
                  <div
                    style={{
                      textAlign: "center",
                      fontSize: "16px",
                    }}
                  >
                    加载中...
                  </div>
                }
                inactive={<NotData />}
              />
            }
          />
        </div>

        <div className="line2">
          <RenderJudge
            value={tomorrowList.length}
            active={
              <div onClick={(e) => handleToTop(e)}>
                <Iconfont name="fanhuidingbu" className={"icon"} /> 顶部
              </div>
            }
          />
        </div>
      </div>
    </div>
  );
};

export default WrapList;
