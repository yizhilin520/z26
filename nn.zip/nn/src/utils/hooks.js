import { useCallback, useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
// eslint-disable-next-line import/extensions
import SocketClient from "socket.io-client";
import { addEventListener, empty, removeEventListener } from "./common";

/**
 * 获取当前组件是否已经卸载的 hook，用于避免因组件卸载后更新状态而导致的内存泄漏
 */
export const useUnmountedRef = () => {
  const unmountedRef = useRef(false);
  useEffect(
    () => () => {
      unmountedRef.current = true;
    },
    []
  );

  return unmountedRef;
};

/**
 * 用法与 React.useState 完全一样，但是在组件卸载后异步回调内的 setState 不再执行，避免因组件卸载后更新状态而导致的内存泄漏
 */
export const useSafeState = (initialState) => {
  const unmountedRef = useUnmountedRef();
  const [state, setState] = useState(initialState);
  const setCurrentState = (currentState) => {
    /** 如果组件已经卸载则不再更新 state */
    if (unmountedRef.current) return;

    return setState(currentState);
  };

  return [state, setCurrentState];
};

/**
 * 持久化 function
 * @param fn
 * @return {undefined}
 */
export const usePersistFn = (fn = empty) => {
  const fnRef = useRef(fn);
  fnRef.current = fn;

  const persistFn = useRef();
  if (!persistFn.current) {
    // eslint-disable-next-line func-names
    persistFn.current = function (...args) {
      return fnRef.current.apply(this, args);
    };
  }

  return persistFn.current;
};

/**
 * 管理 object 类型 state 的 Hooks，用法与 class 组件的 this.setState 基本一致。
 * @param initialState
 */
export const useSetState = (initialState = {}) => {
  const [state, setState] = useSafeState(initialState);
  const setMergeState = useCallback((patch) => {
    setState((prevState) => ({
      ...prevState,
      ...(typeof patch === "function" ? patch(prevState) : patch),
    }));
  }, []);

  return [state, setMergeState];
};

/**
 * 请求封装
 * @param fetchHandle 请求函数
 * @param reqData 请求数据
 * @param callback  回调
 * @return {data:数据, loading:加载状态, error：请求错误, mutate: 手动触发}
 */
// export const useRequest = (fetchHandle, reqData, callback = empty) => {
//   const [data, setData] = useSafeState();
//   const [loading, setLoading] = useSafeState(true);
//   const [error, setError] = useSafeState();

//   const requestHandle = async (d = reqData) => {
//     setLoading(true);
//     try {
//       const { data: rD } = await fetchHandle(d);
//       const rData = rD || {};
//       const { code, data: resData, msg } = rData;
//       if (code === HttpCode.SUCCESS) {
//         setData(await callback(resData) || resData);
//       } else {
//         setError(new Error(msg));
//       }
//     } catch (e) {
//       setError(e);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     (async () => {
//       await requestHandle(reqData);
//     })();
//   }, []);

//   return {
//     data, loading, error, mutate: requestHandle
//   };
// };

/**
 * websocket推送
 * @param _path 路径
 * @param msgCallback 消息回调
 * @return socket.io-client实例
 */
export const useWebsocketPush = (_path = "/", msgCallback = empty) => {
  const [instance, setInstance] = useSafeState();

  useEffect(() => {
    const socketInstance = SocketClient(
      `${process.env.WEBSOCKET_PUSH_API}${_path}`,
      { transports: ["websocket", "xhr-polling", "jsonp-polling"] }
    );

    socketInstance.on("message", (str) => {
      let result = {};
      try {
        result = JSON.parse(str);
      } catch (e) {
        result = str;
      }

      msgCallback(result);
    });

    setInstance(socketInstance);

    return () => {
      if (socketInstance) socketInstance.disconnect();
    };
  }, []);

  return instance;
};

// 显示星期几
export const showDays = (days) => {
  switch (days) {
    case 1:
      days = "星期一";
      break;
    case 2:
      days = "星期二";
      break;
    case 3:
      days = "星期三";
      break;
    case 4:
      days = "星期四";
      break;
    case 5:
      days = "星期五";
      break;
    case 6:
      days = "星期六";
      break;
    case 0:
      days = "星期日";
      break;
  }
  return days
};
