import * as HistoryCreator from 'history';

const history = HistoryCreator.createBrowserHistory;

export default history;