import axios from "axios";
import Qs from "querystring";
import { getToken, removeToken } from "@/utils/auth";

const service = axios.create({
  baseURL:
    process.env.NODE_ENV === "production" ? process.env.REACT_APP_BASE_URL : process.env.REACT_APP_DEV_URL,
  timeout: 30000, // request timeout
});

// request interceptor
service.interceptors.request.use(
  (config) => {
    if (getToken()) {
      config.headers["Authorization"] = getToken(); // 让每个请求携带自定义token 请根据实际情况自行修改
    } else {
      config.headers["Authorization"] = "";
    }
    switch (config.dataType) {
      case "formData":
        config.headers["Content-Type"] =
          "application/x-www-form-urlencoded;charset=utf-8";
        config["data"] = Qs.stringify(config.data);
        break;
      default:
        config.headers["Content-Type"] = "application/json";
        config.headers["Accept-Language"] = "zh-CN,zh;q=0.9";
    }
    // console.log('config :>> ', config);
    return config;
  },
  (error) => {
    // do something with request error
    console.error(error); // for debug
    return Promise.reject(error);
  }
);
// response interceptor
service.interceptors.response.use(
  (response) => {
    const res = response.data;
    if (res.code !== 200) {
      switch (res.code * 1) {
        case 999:
          console.log(res.msg);
          break;
        case 401:
          removeToken();
          // setTimeout(() => {
          //   window.location.reload();
          // }, 100);
          break;
        default:
          console.log(res.msg);
      }
      return res;
    } else {
      console.log(res.msg);
      return res;
    }
  },
  (error) => {
    console.log("err", error);
    return Promise.reject(error);
  }
);

export default service;
