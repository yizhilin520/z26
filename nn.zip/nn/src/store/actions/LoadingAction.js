import { SHOW_LOADING, GET_TOKEN } from "../type/ActionTypes";
export function showLoading(payload) {
  return {
    type: SHOW_LOADING,
    loading: payload,
  };
}
export function getToken(payload) {
  return {
    type: GET_TOKEN,
    loading: payload,
  };
}
