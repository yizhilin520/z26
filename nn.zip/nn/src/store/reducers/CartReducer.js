let initState = {
    totalNum: 0
}

export const CartReducer = (state = initState, action) => {
    switch (action.type) {
        case 'ADD_CART':
            state.totalNum += 1
            return {...state}
        // 点击结算时保存购物车数据
        case 'BUY_NOW':
            return {...state, ...action.payload}
        case 'CLEAR': 
            return {}
        default:
        // 返回默认数据
        return state
    }
    
}