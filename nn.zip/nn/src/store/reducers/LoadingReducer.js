import { SHOW_LOADING } from "../type/ActionTypes";

let initValue = {
  loading: false,
};
export const LoadingReducer = (state = initValue, actions) => {
  switch (actions.type) {
    case SHOW_LOADING:
      return {
        ...state,
        loading: actions.loading,
      };
    default:
      return state;
  }
};
