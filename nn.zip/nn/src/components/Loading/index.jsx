import React from "react";
import { ActivityIndicator } from "antd-mobile";
import './style.scss'

const Loading = ({ show }) => {
  return (
    <div className="loading">
      <ActivityIndicator toast text="加载中" animating={show} />
    </div>
  );
};

export default Loading;
