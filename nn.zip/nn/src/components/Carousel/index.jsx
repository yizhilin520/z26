import React, { useState } from "react";
import { Link } from "react-router-dom";
import Slider from "react-slick";
import Image from "@/components/Image";

// slick-carousel
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import "./style.scss";

const Carousel = (props) => {
  const { list, height } = props;
  const [options, setOptions] = useState({
    dots: true,
    infinite: true,
    speed: 500,
    int: 1000,
    arrows: false,
    autoplay: true,
    appendDots: (dots) => <ul>{dots}</ul>,
  });

  return (
    <div className="cus_swiper" style={{ height: height }}>
      <Slider {...options}>
        {list.map((it, idx) => (
          <div className="cus_box" key={idx}>
            <Link to={it.url || "#"} target="_blank">
              <Image src={it.content} />
            </Link>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default Carousel;
