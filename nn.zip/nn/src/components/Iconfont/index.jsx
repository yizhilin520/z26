import React from 'react';
import ClassNames from 'classnames';

import './style.scss';

const Iconfont = ({ tag, name, className, style, children, ...props }) => React.createElement(
  tag,
  { ...props || {}, className: ClassNames("iconfont", `icon-${name}`, className), style },
  children
);

Iconfont.defaultProps = {
  tag: 'i'
};

export default Iconfont;
