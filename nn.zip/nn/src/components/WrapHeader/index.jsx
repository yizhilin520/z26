import React from "react";
import { Link } from "react-router-dom";
import Image from "@/components/Image";
import Logo from "@/assets/imgs/logo.png";
import "./style.scss";

const WrapHeader = () => {
  return (
    <div className="wrap_header">
      <Link to="/">
        <Image src={Logo} />
      </Link>
    </div>
  );
};

export default WrapHeader;
