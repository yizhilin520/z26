import React, { useEffect, useState } from 'react';
import { useSafeState } from '@/utils/hooks';

const Image = ({ className, src,alt, defaultImage, ...props }) => {
  const [loadFlag, setLoadFlag] = useState(false);
  const [videoImage, setVideoImage] = useSafeState(src || defaultImage);

  const onImageErrorHandle = () => {
    if (!loadFlag) {
      setVideoImage(defaultImage);
      setLoadFlag(true)
    }
  };

  useEffect(() => {
    if (src) {
      setVideoImage(src);
      setLoadFlag(false)
    }
  }, [src]);

  return (
    <img
      onError={onImageErrorHandle}
      className={className}
      src={videoImage}
      {...props}
      alt={alt}
    />
  );
};

export default Image;
