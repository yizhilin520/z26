import React from 'react';
import ClassNames from 'classnames';
import RenderJudge from '@/components/RenderJudge';
import DefaultNotDataImage from '@/assets/imgs/default_not_data_image.png';

import './style/index.scss';

const NotData = ({ image, text, className, ...props }) => (
  <div className={ClassNames("nodata_container", "className")} {...props}>
    <img className={"image"} src={image} />
    <RenderJudge
      value={text}
      active={(<div className={"text_txt"}>{text}</div>)}
    />
  </div>
);

NotData.defaultProps = {
  image: DefaultNotDataImage,
  text: '暂无数据'
};

export default NotData;
