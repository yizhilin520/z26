import React from "react";
import { Link } from "react-router-dom";
import Image from "@/components/Image";
import Logo from "@/assets/imgs/logo.png";
import "./style.scss";

const Header = ({ show = true }) => {
  return (
    <div className="header">
      <div className="wrap">
        <div className="logo">
          <Link to="/">
            <Image src={Logo} />
          </Link>
        </div>
        <div className="beiyong" style={{ display: show ? "block" : "none" }}>
          <Link target="_blank" to="www.keezhibo.com">
            <span className="address">永久地址：www.keezhibo.com</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Header;
