import React from 'react';
import ZIndex from '@/components/zIndex';

import  '../style/Loading.scss';

const Loading = () => (
  <ZIndex className="container" />
);

export default Loading;
