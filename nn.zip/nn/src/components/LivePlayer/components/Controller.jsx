// import React, { useRef } from "react";
// import ClassNames from "classnames";
// import RenderJudge from "@/components/RenderJudge";
// import ZIndex from "@/components/zIndex";
// import { useStores } from "../utils/store";

// import Image from "@/components/Image";

// import PlayImg from "@/assets/imgs/play.png";
// import PauseImg from "@/assets/imgs/pause.png";
// import RefreshImg from "@/assets/imgs/refresh.png";
// import ExitFullScreenImg from "@/assets/imgs/fullScreen.png";
// import FullScreenImg from "@/assets/imgs/full.png";

// import "../style/Controller.scss";


// const Controller = ({ left, center, right }) => {
//   const { status } = useStores();
//   return (
//     <ZIndex
//       className={ClassNames("controller", { isVisible: status.ctrlVisible })}
//     >
//       <div className="wrapper">
//         <div className={ClassNames("inner", "isLeft")}>{left}</div>
//         <div className={ClassNames("inner", "isCenter")}>{center}</div>
//         <div className={ClassNames("inner", "isRight")}>{right}</div>
//       </div>
//     </ZIndex>
//   );
// };

// // 播放
// export const Play = () => {
//   const { status, methods } = useStores();
//   return (
//     <RenderJudge
//       value={status.paused}
//       active={
//         // <CtrlTooltip title="播放">
//         <>
//           <div className={ClassNames("item")} onClick={methods.play}>
//             <Image src={PauseImg} className="icon" />
//           </div>
//         </>
//         // </CtrlTooltip>
//       }
//     />
//   );
// };
// // 暂停
// export const Pause = () => {
//   const { status, methods } = useStores();
//   return (
//     <RenderJudge
//       value={status.played}
//       active={
//         // <CtrlTooltip title="暂停">
//         <>
//           <div className={ClassNames("item")} onClick={methods.pause}>
//             <Image src={PlayImg} className="icon" />
//           </div>
//         </>
//         // </CtrlTooltip>
//       }
//     />
//   );
// };
// // 刷新
// export const Refresh = () => {
//   const { methods } = useStores();
//   return (
//     <div className={ClassNames("item")} onClick={methods.create}>
//       <Image src={RefreshImg} className="icon" />
//     </div>
//   );
// };
// // // 画质
// // const Quality = () => {
// //   const { data: { index, list, setIndex } } = useStores();

// //   const { name } = list[index] || {};

// //   return (
// //     <RenderJudge
// //       value={list.length}
// //       active={(
// //         <div className={ClassNames("item", "isQuality")}>
// //           <div className="qualityText">{name}</div>
// //           <div className="qualityWrapper">
// //             {list.map((row, rowIndex) => (
// //               <div
// //                 className={ClassNames("qualityItem", { "isActive": rowIndex === index })}
// //                 onClick={() => setIndex(rowIndex)}
// //                 key={rowIndex}
// //               >
// //                 {row.name}
// //               </div>
// //             ))}
// //           </div>
// //         </div>
// //       )}
// //     />
// //   );
// // };
// // 音量
// // const Volume = () => {
// //   const { status: { volume, muted }, methods } = useStores();
// //   const onChange = (e, v) => methods.volume(v / 100);
// //   return (
// //     <>
// //       {/* <CtrlTooltip title="音量"> */}
// //         <>
// //         <div className="item" onClick={methods.switchVolume}>
// //           {/* <RenderJudge
// //             value={muted}
// //             active={(<Iconfont name="jingyin" className="icon" />)}
// //             inactive={(<Iconfont name="yinliang" className="icon"/>)}
// //           /> */}
// //         </div>
// //         </>
// //       {/* </CtrlTooltip> */}
// //       <div className={ClassNames("item", "isVolumeBar")}>
// //         {/* <CtrlSlider
// //           min={0}
// //           max={100}
// //           step={1}
// //           value={volume * 100}
// //           onChange={onChange}
// //           valueLabelDisplay="auto"
// //           valueLabelFormat={(num) => Math.floor(num || 0)}
// //         /> */}
// //       </div>
// //     </>
// //   );
// // };

// // 全屏
// export const FullScreen = () => {
//   const { status, methods } = useStores();
//   return (
//     <RenderJudge
//       value={status.fullScreen}
//       inactive={
//         // <CtrlTooltip title="全屏">
//         <>
//           <div className={ClassNames("item")} onClick={methods.fullScreen}>
//             <Image src={FullScreenImg} className="icon" />
//           </div>
//         </>
//         // </CtrlTooltip>
//       }
//     />
//   );
// };
// // 退出全屏
// const ExitFullScreen = () => {
//   const { status, methods } = useStores();
//   return (
//     <RenderJudge
//       value={status.fullScreen}
//       active={
//         // <CtrlTooltip title="退出全屏">
//         <>
//           <div className={ClassNames("item")} onClick={methods.exitScreen}>
//           <Image src={ExitFullScreenImg} className="icon" />
//             {/* <Iconfont name="tuichuquanping" className="icon" /> */}
//           </div>
//         </>
//         // </CtrlTooltip>
//       }
//     />
//   );
// };

// Controller.defaultProps = {
//   left: (
//     <>
//       <Play />
//       <Pause />
//       <Refresh />
//     </>
//   ),
//   center: null,
//   right: (
//     <>
//       {/* <Quality /> */}
//       {/* <Volume /> */}
//       <FullScreen />
//       <ExitFullScreen />
//     </>
//   ),
// };

// export default Controller;



import React from 'react';
import ClassNames from 'classnames';
import Slider from '@material-ui/core/Slider';
import Tooltip from '@material-ui/core/Tooltip';
import { withStyles } from '@material-ui/core/styles';
import Iconfont from '@/components/Iconfont';
import RenderJudge from '@/components/RenderJudge';
import { useStores } from '../utils/store';

import '../style/Controller.scss';

const CtrlSlider = withStyles({
  root: {
    color: '#aaa9a9',
    width: '90px',
    height: '2px',
  },
  thumb: {
    '&:focus, &:hover': {
      boxShadow: 'inherit',
    }
  }
})(Slider);

const CtrlTooltip = ({ title, open, children }) => (
  <Tooltip title={title} open={open} placement="top" arrow PopperProps={{ disablePortal: true }}>
    {children}
  </Tooltip>
);

const Controller = ({ left, center, right }) => {
  const { status } = useStores();
  return (
    <div className={ClassNames("ctr_container", { "isVisible": status.ctrlVisible })}>
      <div className={"ctr_wrapper"}>
        <div className={ClassNames("inner","isLeft")}>
          {left}
        </div>
        <div className={ClassNames("inner","isCenter")}>
          {center}
        </div>
        <div className={ClassNames("inner", "isRight")}>
          {right}
        </div>
      </div>
    </div>
  );
};

// 播放
export const Play  = () => {
  const { status, methods } = useStores();
  return (
    <RenderJudge
      value={status.paused}
      active={(
        <CtrlTooltip title="播放">
          <div className={ClassNames("item")} onClick={methods.play}>
            <Iconfont name="bofang" className={"icon"} />
          </div>
        </CtrlTooltip>
      )}
    />
  );
};
// 暂停
export const Pause = () => {
  const { status, methods } = useStores();
  return (
    <RenderJudge
      value={status.played}
      active={(
        <CtrlTooltip title="暂停">
          <div className={ClassNames("item")} onClick={methods.pause}>
            <Iconfont name="zanting" className={"icon"} />
          </div>
        </CtrlTooltip>
      )}
    />
  );
};
// 刷新
export const  Refresh = () => {
  const { methods } = useStores();
  return (
    <CtrlTooltip title="刷新">
      <div className={ClassNames("item")} onClick={methods.refresh}>
        <Iconfont name="shuaxin" className={"icon"} />
      </div>
    </CtrlTooltip>
  );
};
// 画质
// Controller.Quality = () => {
//   const { data: { index, list, setIndex } } = useStores();

//   const { name } = list[index] || {};

//   return (
//     <RenderJudge
//       value={list.length}
//       active={(
//         <div className={ClassNames("item", "isQuality")}>
//           <div className={"qualityText"}>{name}</div>
//           <div className={"qualityWrapper"}>
//             {list.map((row, rowIndex) => (
//               <div
//                 className={ClassNames(styles.qualityItem, { [styles.isActive]: rowIndex === index })}
//                 onClick={() => setIndex(rowIndex)}
//                 key={rowIndex}
//               >
//                 {row.name}
//               </div>
//             ))}
//           </div>
//         </div>
//       )}
//     />
//   );
// };
// 音量
export const Volume = () => {
  const { status: { volume, muted }, methods } = useStores();
  const onChange = (e, v) => methods.volume(v / 100);
  return (
    <>
      <CtrlTooltip title="音量">
        <div className={"item"} onClick={methods.switchVolume}>
          <RenderJudge
            value={muted}
            active={(<Iconfont name="jingyin" className={"icon"} />)}
            inactive={(<Iconfont name="yinliang" className={"icon"} />)}
          />
        </div>
      </CtrlTooltip>
      <div className={ClassNames("item", "isVolumeBar")}>
        <CtrlSlider
          min={0}
          max={100}
          step={1}
          value={volume * 100}
          onChange={onChange}
          valueLabelDisplay="auto"
          valueLabelFormat={(num) => Math.floor(num || 0)}
        />
      </div>
    </>
  );
};
// 全屏
export const FullScreen = () => {
  const { status, methods } = useStores();
  return (
    <RenderJudge
      value={status.fullScreen}
      inactive={(
        <CtrlTooltip title="全屏">
          <div className={ClassNames("item")} onClick={methods.fullScreen}>
            <Iconfont name="quanping" className={"icon"} />
          </div>
        </CtrlTooltip>
      )}
    />
  );
};
// 退出全屏
export const ExitFullScreen = () => {
  const { status, methods } = useStores();
  return (
    <RenderJudge
      value={status.fullScreen}
      active={(
        <CtrlTooltip title="退出全屏">
          <div className={ClassNames("item")} onClick={methods.exitScreen}>
            <Iconfont name="tuichuquanping" className={"icon"} />
          </div>
        </CtrlTooltip>
      )}
    />
  );
};
// // 打开画中画
// export const OpenPictureInPicture = () => {
//   const { status, methods } = useStores();
//   return (
//     <RenderJudge
//       value={status.pictureInPicture}
//       inactive={(
//         <CtrlTooltip title="打开画中画">
//           <div className={ClassNames("item")} onClick={methods.openPictureInPicture}>
//             <Iconfont name="open-pip" className={"icon"} />
//           </div>
//         </CtrlTooltip>
//       )}
//     />
//   );
// };
// // 关闭画中画
// export const ClosePictureInPicture = () => {
//   const { status, methods } = useStores();
//   return (
//     <RenderJudge
//       value={status.pictureInPicture}
//       active={(
//         <CtrlTooltip title="关闭画中画">
//           <div className={ClassNames("item")} onClick={methods.closePictureInPicture}>
//             <Iconfont name="exit-pip" className={"icon"} />
//           </div>
//         </CtrlTooltip>
//       )}
//     />
//   );
// };

Controller.defaultProps = {
  left: (
    <>
      <Play />
      <Pause />
      <Refresh />
    </>
  ),
  center: null,
  right: (
    <>
      {/* <Controller.Quality /> */}
      <Volume />
      {/* <OpenPictureInPicture /> */}
      {/* <ClosePictureInPicture /> */}
      <FullScreen />
      <ExitFullScreen />
    </>
  )
};

export default Controller;
