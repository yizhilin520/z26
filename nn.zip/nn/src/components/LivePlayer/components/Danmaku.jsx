import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import ZIndex from '@/components/zIndex';
import GeneralEngine from 'openbse/dist/engines/generalEngine';

import styles from '../style/Danmaku.scss';

const Danmaku = forwardRef((props, ref) => {
  // const [instance, setInstance] = useSafeState();
  const containerRef = useRef();
  const danmakuRef = useRef();
  const danmakuIns = danmakuRef.current;

  useEffect(() => {
    const ins = new GeneralEngine(containerRef.current, {
      defaultStyle: {
        shadowBlur: 0,
        fontWeight: 400,
        size: 22,
        boxColor: null,
        color: '#fff',
        fontFamily: 'PingFang SC,Helvetica Neue,Helvetica,Arial,Hiragino Sans GB,Microsoft YaHei,sans-serif'
      },
      verticalInterval: 10,
      playSpeed: 1.5,
      cursorOnMouseOver: 'default'
    });
    ins.play();

    danmakuRef.current = ins;

    return () => ins.stop();
  }, []);

  const pushHandle = (text, isSelf) => {
    if (!danmakuIns) return;
    return danmakuIns.add({
      text,
      style: {
        boxColor: isSelf ? '#fff' : null
      }
    });
  };

  useImperativeHandle(ref, () => ({
    push: pushHandle
  }));

  return (
    <ZIndex className={styles.container}>
      <div className={styles.wrapper} ref={containerRef} />
    </ZIndex>
  );
});

export default Danmaku;
