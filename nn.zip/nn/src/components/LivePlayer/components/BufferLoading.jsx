// import React from 'react';
// import CircularProgress from '@material-ui/core/CircularProgress';
// import { withStyles } from '@material-ui/core/styles';
// import ZIndex from '@/components/zIndex';

// import '../style/BufferLoading.scss';

// // const CircularLoading = withStyles(() => ({
// //   colorPrimary: {
// //     color: '#fff'
// //   }
// // }))(CircularProgress);

// const BufferLoading = () => (<div>123</div>);

// export default BufferLoading;
