import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
} from "react";
import { addOnceEventListener } from "@/utils/common";
import { useSetState } from "@/utils/hooks";
import Controller from "./components/Controller";
import Provider from "./components/Provider";
import { useStores } from "./utils/store";

import "./style/index.scss";

const Main = forwardRef(({ ctrl }, ref) => {
  const {methods } = useStores();

  useImperativeHandle(ref, () => ({
    create: methods.create,
    destroy: methods.destroy,
  }));

  return <>{ctrl}</>;
});

const LivePlayer = forwardRef(({ data, ctrl, children }, ref) => {
  const fullscreenTimer = useRef(null);
  const containerRef = useRef();
  const [status, setStatus] = useSetState({
    fullScreen: false,
    ctrlVisible: false,
  });
  // 清除全屏控制条时间实例
  const clearFullScreenCtrlTimer = () => clearTimeout(fullscreenTimer.current);
  // 设置全屏控制条显隐
  const setFullScreenCtrlVisible = () => {
    clearFullScreenCtrlTimer();
    if (!status.fullScreen) return;

    fullscreenTimer.current = setTimeout(
      () => setStatus({ ctrlVisible: false }),
      3000
    );
  };
  const methods = {
    // 全屏
    fullScreen() {
      const container = containerRef.current;
      if (!container) return;

      setStatus({ fullScreen: true });

      const handler =
        container.requestFullscreen ||
        container.mozRequestFullScreen ||
        container.webkitRequestFullscreen ||
        container.msRequestFullscreen;
      return handler.call(container);
    },
    // 退出全屏
    exitScreen() {
      const handler =
        document.cancelFullScreen ||
        document.mozCancelFullScreen ||
        document.webkitCancelFullScreen ||
        document.msCancelFullScreen ||
        document.msExitFullscreen;

      setStatus({ fullScreen: false });

      return handler.call(document);
    },
  };
  const onSetCtrlVisibleHandle = (ctrlVisible) => {
    setFullScreenCtrlVisible();

    return setStatus({ ctrlVisible });
  };
  useEffect(() => {
    addOnceEventListener(window, "resize", () => {
      setStatus({
        fullScreen:
          document.fullscreenElement ||
          document.mozFullScreenElement ||
          document.webkitFullscreenElement ||
          document.msFullscreenElement,
      });
    });

    return clearFullScreenCtrlTimer;
  }, []);
  return (
    // eslint-disable-next-line jsx-a11y/mouse-events-have-key-events
    <div
      ref={containerRef}
      className="play_container"
      onMouseEnter={() => onSetCtrlVisibleHandle(true)}
      onMouseOver={() => onSetCtrlVisibleHandle(true)}
      onMouseOut={() => onSetCtrlVisibleHandle(false)}
      onMouseMove={() => onSetCtrlVisibleHandle(true)}
    >
      <Provider data={data} status={status} methods={methods}>
        <Main ref={ref} ctrl={ctrl} />
        {children}
      </Provider>
    </div>
  );
});

LivePlayer.defaultProps = {
  data: [],
  ctrl: <Controller />,
};

export default LivePlayer;
