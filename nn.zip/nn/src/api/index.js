import request from "@/utils/request";

//获取token
export function login(data) {
  return request({
    url: "/user/login",
    method: "post",
    dataType: "formData",
    data,
  });
}

// 查询今日历史赛事
export const getTodayMatchList = (params) =>
  request({
    url: "/match/getToday",
    method: "get",
    dataType: "formData",
    params: {
      ...params,
      _timestamp: +new Date(),
    },
  });

// 查询明日历史赛事
export const getTomorrowMatchList = (params) =>
  request({
    url: "/match/getTomorrow",
    method: "get",
    dataType: "formData",
    params: {
      ...params,
      _timestamp: +new Date(),
    },
  });

// 查询今日单个比赛的播放地址
export const getOnceMatchList = (params) =>
  request({
    url: "/match/getMatchInfo",
    method: "get",
    dataType: "formData",
    params: {
      ...params,
      _timestamp: +new Date(),
    },
  });
// 查询明日单个比赛的播放地址
export const getTomorrowMatchInfo = (params) =>
  request({
    url: "/match/getTomorrowMatchInfo",
    method: "get",
    dataType: "formData",
    params: {
      ...params,
      _timestamp: +new Date(),
    },
  });

// 查询广告 /match/config
export const getadConfig = (params) =>
  request({
    url: "/match/config",
    method: "get",
    dataType: "formData",
    params: {
      ...params,
      _timestamp: +new Date(),
    },
  });
