import React, { lazy, Suspense, useEffect } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";

import history from "@/utils/history";
import { setToken, getToken } from "@/utils/auth";
import { login } from "@/api";

import Loading from "@/components/Loading/index.jsx";

import MatchPage from "@/views/matchPage/MatchPage";
import DetailPage from "@/views/detailPage/DetailPage";
import WrapDetailPage from "@/views/wrapDetailPage/WrapDetailPage";

function App() {
  useEffect(() => {
    if (getToken()) {
      return;
    } else {
      let params = {
        account: "admin",
        password: "6d40214931496e674d6674756547534a",
      };
      login({ ...params })
        .then((res) => {
          if (res.code * 1 === 200) {
            setToken(res.data);
            window.location.reload();
          }
        })
        .catch(() => {});
    }
  }, []);
  return (
    <Router history={history}>
      <Suspense fallback={<Loading />}>
        <Switch>
          <Route
            path="/"
            exact
            render={(props) => <MatchPage {...props}></MatchPage>}
          ></Route>
          <Route
            path="/detail/:type/:id"
            exact
            render={(props) => <DetailPage {...props}></DetailPage>}
          ></Route>
          <Route
            path="/wrap_detail/:type/:id"
            exact
            render={(props) => <WrapDetailPage {...props}></WrapDetailPage>}
          ></Route>
          <Redirect from={"*"} to={"/"} />
        </Switch>
      </Suspense>
    </Router>
  );
}

export default App;
