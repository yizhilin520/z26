const {
  override,
  addBabelPlugins,
  fixBabelImports,
  addWebpackAlias,
  addPostcssPlugins,
  overrideDevServer,
  disableEsLint,
  addWebpackPlugin,
  useBabelRc,
} = require("customize-cra");

// 修改打包文件夹名
const path = require("path");
const paths = require("react-scripts/config/paths");
paths.appBuild = path.join(path.dirname(paths.appBuild), "dist");

const ProgressBarPlugin = require("progress-bar-webpack-plugin");
const rewireCssModules = require("react-app-rewire-css-modules");

// 关闭map文件
process.env.GENERATE_SOURCEMAP = "false";

const cssModules = () => (config) => {
  return rewireCssModules(config);
};

/**
 * 生产环境是否打包 Source Map 两种方法
 *
 */
const rewiredMap = () => (config) => {
  config.devtool =
    config.mode === "development" ? "cheap-module-source-map" : false;

  return config;
};
process.env.PORT = 3006;

process.env.GENERATE_SOURCEMAP !== "false";

const addProxy = () => (configFunction) => {
    configFunction.proxy = {
      "/api": {
        target: process.env.REACT_APP_DEV_URL,
        changeOrigin: true,
        secure: false,
        pathRewrite: { "^/api": "" },
      },
    };

  return configFunction;
};

module.exports = {
  webpack: override(
    // plugins配置方法设置在这里，也可以放到.babelrc文件里，但要在override开启.babelrc才能用
    useBabelRc(),
    //css模块化
    cssModules(),
    // 配置支持@根路径
    addWebpackAlias({
      "@": path.resolve("./src"),
    }),
    // 配置px转rem
    // addPostcssPlugins([
    //   require("postcss-px2rem")({ remUnit: 37.5, exclude: /node-modules/i }),
    // ]),
    fixBabelImports("import", {
      libraryName: "antd-mobile",
      libraryDirectory: "es",
      style: "css",
    }),
    addBabelPlugins(["@babel/plugin-proposal-decorators", { legacy: true }]),
    addWebpackPlugin(new ProgressBarPlugin()),
    // 关闭mapSource
    rewiredMap(),
    disableEsLint()
  ),
  devServer: overrideDevServer(addProxy()),
};
